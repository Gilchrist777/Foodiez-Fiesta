import React from 'react';

interface KioskLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'splash';
  animated?: boolean;
  className?: string;
  customLogoUrl?: string | null;
}

export const KioskLogo: React.FC<KioskLogoProps> = ({
  size = 'md',
  animated = false,
  className = '',
  customLogoUrl = null,
}) => {
  const sizeMap = {
    xs: 'w-6 h-6',
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24',
    splash: 'w-32 h-32 sm:w-36 sm:h-36',
  };

  if (customLogoUrl) {
    return (
      <div className={`relative flex items-center justify-center shrink-0 ${sizeMap[size]} ${className}`}>
        <img
          src={customLogoUrl}
          alt="Foodiez Fiesta Logo"
          className="w-full h-full object-contain drop-shadow-md rounded-2xl"
        />
      </div>
    );
  }

  // Minimal trendy luxury vector logo: Geometric Black & Gold Foodiez Fiesta Emblem
  return (
    <div
      className={`relative flex items-center justify-center shrink-0 select-none ${sizeMap[size]} ${className} ${
        animated ? 'group' : ''
      }`}
    >
      {/* Outer ambient golden glow */}
      {(animated || size === 'splash' || size === 'xl') && (
        <div className="absolute inset-0 rounded-2xl sm:rounded-3xl bg-amber-400/25 blur-xl animate-pulse -z-10 pointer-events-none" />
      )}

      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-xl overflow-visible"
      >
        <defs>
          {/* Deep Obsidian Black gradient */}
          <linearGradient id="blackGoldBg" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#1C1917" />
            <stop offset="50%" stop-color="#0C0A09" />
            <stop offset="100%" stop-color="#000000" />
          </linearGradient>

          {/* Imperial Gold Gradient */}
          <linearGradient id="goldFlameGrad" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stop-color="#B45309" />
            <stop offset="40%" stop-color="#F59E0B" />
            <stop offset="80%" stop-color="#FDE047" />
            <stop offset="100%" stop-color="#FFFFFF" />
          </linearGradient>

          <linearGradient id="pureGoldAccent" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#FEF08A" />
            <stop offset="60%" stop-color="#F59E0B" />
            <stop offset="100%" stop-color="#D97706" />
          </linearGradient>

          <filter id="goldGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="#F59E0B" flood-opacity="0.4" />
          </filter>
        </defs>

        {/* Minimal rounded squircle container in Jet Black with Gold Border */}
        <rect
          x="6"
          y="6"
          width="88"
          height="88"
          rx="24"
          fill="url(#blackGoldBg)"
          stroke="url(#pureGoldAccent)"
          stroke-width="2"
          filter="url(#goldGlow)"
        />

        {/* Dynamic decorative background circle */}
        <circle
          cx="50"
          cy="50"
          r="38"
          stroke="#F59E0B"
          stroke-opacity="0.25"
          stroke-width="1.5"
          stroke-dasharray="4 4"
          className={animated ? 'animate-[spin_20s_linear_infinite] origin-center' : ''}
        />

        {/* Stylized Modern Street Food Canopy in Imperial Gold */}
        <path
          d="M26 40 C32 37 40 37 50 40 C60 43 68 43 74 40 L74 45 C68 48 60 48 50 45 C40 42 32 42 26 45 Z"
          fill="url(#pureGoldAccent)"
          opacity="0.95"
        />

        {/* Stylized Fiesta Flame & Double 'F' Geometry */}
        <path
          d="M48 24 C48 24 34 38 34 52 C34 62 42 70 52 70 C53 70 54 70 55 69.8 C48 66 45 59 46 54 C47 48 52 43 53 37 C54 32 51 27 48 24 Z"
          fill="url(#goldFlameGrad)"
          className={animated ? 'animate-[pulse_2s_ease-in-out_infinite]' : ''}
        />

        {/* Center / Right Sizzle Core */}
        <path
          d="M52 35 C52 35 66 45 66 57 C66 65 60 72 52 72 C58 68 60 61 58 56 C56 50 50 47 51 40 C51.5 37 52 35 52 35 Z"
          fill="#FFFBEB"
          opacity="0.95"
        />

        {/* Inner Golden Sparkle */}
        <circle cx="50" cy="56" r="3" fill="#FDE047" />

        {/* Pushcart Baseline Wheels: Minimalist dual accent gold dots */}
        <circle cx="38" cy="77" r="3.5" fill="#F59E0B" />
        <circle cx="62" cy="77" r="3.5" fill="#F59E0B" />
        <line x1="32" y1="77" x2="68" y2="77" stroke="#F59E0B" stroke-opacity="0.5" stroke-width="1.5" stroke-linecap="round" />
      </svg>
    </div>
  );
};
