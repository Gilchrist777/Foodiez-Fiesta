import React, { useEffect, useState } from 'react';
import { KioskLogo } from './KioskLogo';
import { Sparkles } from 'lucide-react';

interface SplashIntroProps {
  onComplete: () => void;
  customLogoUrl?: string | null;
}

export const SplashIntro: React.FC<SplashIntroProps> = ({
  onComplete,
  customLogoUrl = null,
}) => {
  const [phase, setPhase] = useState<'enter' | 'active' | 'exit'>('enter');

  useEffect(() => {
    const t1 = setTimeout(() => setPhase('active'), 80);
    const t2 = setTimeout(() => setPhase('exit'), 1350);
    const t3 = setTimeout(() => {
      onComplete();
    }, 1750);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [onComplete]);

  return (
    <div
      onClick={onComplete}
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-stone-950 text-white select-none transition-opacity duration-400 cursor-pointer overflow-hidden ${
        phase === 'exit' ? 'opacity-0 scale-105 pointer-events-none' : 'opacity-100 scale-100'
      }`}
    >
      {/* Background ambient luxury golden glow */}
      <div className="absolute w-96 h-96 rounded-full bg-amber-500/15 blur-3xl animate-pulse pointer-events-none" />
      <div className="absolute w-64 h-64 rounded-full bg-yellow-400/10 blur-2xl pointer-events-none" />

      {/* Main Logo with trendy entry animation */}
      <div
        className={`relative flex flex-col items-center justify-center transition-all duration-700 ease-out ${
          phase === 'enter'
            ? 'scale-75 opacity-0 translate-y-6'
            : 'scale-100 opacity-100 translate-y-0'
        }`}
      >
        {/* Kinetic ripple rings around logo */}
        <div className="absolute -inset-4 rounded-3xl border border-amber-400/30 animate-[ping_2.5s_cubic-bezier(0,0,0.2,1)_infinite] pointer-events-none" />
        <div className="absolute -inset-8 rounded-full border border-yellow-400/15 animate-[pulse_2s_ease-in-out_infinite] pointer-events-none" />

        {/* The Kiosk Logo in Black & Gold */}
        <KioskLogo size="splash" animated={true} customLogoUrl={customLogoUrl} />

        {/* Brand Name Typography */}
        <div className="mt-6 text-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-300 text-[11px] font-black tracking-widest uppercase mb-2">
            <Sparkles className="w-3 h-3 text-yellow-300 animate-spin" />
            Pushcart Food Kiosk
          </div>
          
          <h1 className="text-3xl sm:text-4xl font-black tracking-wider text-white drop-shadow-xl">
            FOODIEZ <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-400">FIESTA</span>
          </h1>

          <p className="text-xs text-stone-400 font-medium tracking-wide mt-1">
            Order Noting & Daily Sales POS
          </p>
        </div>
      </div>

      {/* Bottom loading indicator & tap hint */}
      <div className="absolute bottom-10 flex flex-col items-center gap-2">
        <div className="w-36 h-1 rounded-full bg-stone-900 border border-stone-800 overflow-hidden">
          <div className="h-full bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 rounded-full animate-[shimmer_1.2s_infinite]" />
        </div>
        <span className="text-[10px] text-stone-500 uppercase tracking-widest font-bold">
          Tap anywhere to start
        </span>
      </div>
    </div>
  );
};
