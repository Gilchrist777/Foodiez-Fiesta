import React, { useState } from 'react';
import { KioskLogo } from './KioskLogo';
import { PWAInstallButton } from './PWAInstallButton';
import { Settings, Store, BarChart2, Link, Check } from 'lucide-react';

interface HeaderProps {
  onOpenSettings: () => void;
  onOpenReports: () => void;
  customLogoUrl: string | null;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSettings,
  onOpenReports,
  customLogoUrl,
}) => {
  const [copiedLink, setCopiedLink] = useState(false);

  const handleCopyAppLink = async () => {
    try {
      const url = window.location.href;
      await navigator.clipboard.writeText(url);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    } catch {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-[#0b0b0d]/95 backdrop-blur-md border-b border-[#E6B325]/20 px-3.5 sm:px-5 py-3 shadow-2xl">
      <div className="max-w-3xl mx-auto flex items-center justify-between gap-3">
        {/* Left: Brand & Trendy Animated Kiosk Logo */}
        <div className="flex items-center gap-3">
          <KioskLogo size="sm" customLogoUrl={customLogoUrl} animated={true} />
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-base sm:text-lg font-extrabold tracking-tight text-[#F5F5F7] leading-none">
                Foodiez <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#F5D061] via-[#E6B325] to-[#B8860B]">Fiesta</span>
              </h1>
              <span className="hidden xs:inline-flex items-center gap-0.5 rounded-full bg-[#E6B325]/15 text-[#F5D061] px-2 py-0.5 text-[10px] font-bold border border-[#E6B325]/25">
                <Store className="w-2.5 h-2.5" />
                PUSHCART
              </span>
            </div>
            <p className="text-[10.5px] sm:text-[11px] text-stone-400 font-medium tracking-wide">
              Daily Kiosk POS & Sales
            </p>
          </div>
        </div>

        {/* Right Corner: Quick Tools (Copy Link, Reports Drawer, Settings, PWA Install) */}
        <div className="flex items-center gap-2">
          {/* PWA Install Button (Compact) */}
          <PWAInstallButton compact={true} />

          {/* Copy/Share App URL for Brother */}
          <button
            onClick={handleCopyAppLink}
            className="p-2 rounded-xl text-stone-300 hover:text-[#F5D061] hover:bg-white/[0.06] border border-white/10 transition cursor-pointer"
            title="Copy App URL to send to brother"
          >
            {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Link className="w-4 h-4" />}
          </button>

          {/* Yesterday's Report & Sales Analytics Drawer */}
          <button
            onClick={onOpenReports}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-stone-200 hover:text-[#F5D061] bg-white/[0.04] hover:bg-white/[0.08] border border-[#E6B325]/30 transition cursor-pointer text-xs font-semibold"
            title="Reports & Analytics"
          >
            <BarChart2 className="w-4 h-4 text-[#E6B325]" />
            <span className="hidden sm:inline">Reports</span>
          </button>

          {/* Master Menu & Settings */}
          <button
            onClick={onOpenSettings}
            className="p-2 rounded-xl text-stone-300 hover:text-[#F5D061] hover:bg-white/[0.06] border border-white/10 transition cursor-pointer"
            title="Master Menu Items & Logo Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
